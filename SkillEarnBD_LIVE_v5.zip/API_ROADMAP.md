# API roadmap
Auth: POST /auth/register, /auth/login, /auth/otp/verify
Jobs: GET/POST /api/jobs, POST /api/jobs/:id/apply
Services: GET/POST /api/services
Orders: POST/GET/PATCH /api/orders
Wallet: GET /api/wallet, GET /api/wallet/ledger
Payments: POST /api/payments/checkout, POST /api/payments/webhook
Withdrawals: POST/GET /api/withdrawals
Admin: GET /api/admin/stats, KYC moderation, disputes, withdrawals, audit logs
