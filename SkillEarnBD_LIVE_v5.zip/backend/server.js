const express=require("express");
const crypto=require("crypto");
const app=express();
app.use(express.json({limit:"1mb"}));

const PORT=process.env.PORT||3000;
const COMMISSION=0.10;

// Demo persistence layer. Replace with PostgreSQL/Supabase repository in production.
const store={users:new Map(),jobs:new Map(),services:new Map(),orders:new Map(),ledger:[],withdrawals:new Map(),audit:[]};

function id(prefix){return prefix+"_"+crypto.randomBytes(8).toString("hex")}
function now(){return new Date().toISOString()}
function requireUser(req,res,next){
  const uid=req.header("x-user-id");
  if(!uid || !store.users.has(uid)) return res.status(401).json({error:"authentication_required"});
  req.user=store.users.get(uid); next();
}
function audit(actor,action,target,meta={}){store.audit.push({id:id("audit"),actor,action,target,meta,createdAt:now()})}

app.get("/api/health",(req,res)=>res.json({ok:true,service:"SkillEarn BD",version:"5.0"}));

app.post("/api/auth/register",(req,res)=>{
  const {name,email,phone,role="seller"}=req.body;
  if(!name || (!email&&!phone)) return res.status(400).json({error:"name_and_email_or_phone_required"});
  if(!["buyer","seller"].includes(role)) return res.status(400).json({error:"invalid_role"});
  const uid=id("usr"); store.users.set(uid,{id:uid,name,email,phone,role,kycStatus:"pending",createdAt:now()});
  audit(uid,"register","user:"+uid);
  res.status(201).json({user:store.users.get(uid),note:"Replace demo registration with OTP/password authentication before production."});
});

app.get("/api/me",requireUser,(req,res)=>res.json(req.user));

app.get("/api/jobs",(req,res)=>res.json([...store.jobs.values()].filter(x=>x.status==="open")));
app.post("/api/jobs",requireUser,(req,res)=>{
  if(req.user.role!=="buyer") return res.status(403).json({error:"buyer_only"});
  const {title,description,price}=req.body;
  if(!title || !(Number(price)>0)) return res.status(400).json({error:"invalid_job"});
  const j={id:id("job"),title,description,price:Number(price),createdBy:req.user.id,status:"open",createdAt:now()};
  store.jobs.set(j.id,j); audit(req.user.id,"job.create",j.id); res.status(201).json(j);
});

app.get("/api/services",(req,res)=>res.json([...store.services.values()].filter(x=>x.status==="active")));
app.post("/api/services",requireUser,(req,res)=>{
  if(req.user.role!=="seller") return res.status(403).json({error:"seller_only"});
  const {title,description,price}=req.body;
  if(!title || !(Number(price)>0)) return res.status(400).json({error:"invalid_service"});
  const s={id:id("svc"),sellerId:req.user.id,title,description,price:Number(price),status:"active",createdAt:now()};
  store.services.set(s.id,s); audit(req.user.id,"service.create",s.id); res.status(201).json(s);
});

app.post("/api/orders",requireUser,(req,res)=>{
  const {serviceId}=req.body; const s=store.services.get(serviceId);
  if(!s) return res.status(404).json({error:"service_not_found"});
  if(s.sellerId===req.user.id) return res.status(400).json({error:"cannot_order_own_service"});
  const gross=s.price, commission=Number((gross*COMMISSION).toFixed(2)), net=Number((gross-commission).toFixed(2));
  const o={id:id("ord"),buyerId:req.user.id,sellerId:s.sellerId,serviceId,grossAmount:gross,commission,sellerNet:net,status:"pending",createdAt:now()};
  store.orders.set(o.id,o); audit(req.user.id,"order.create",o.id); res.status(201).json(o);
});

app.get("/api/orders",requireUser,(req,res)=>{
  res.json([...store.orders.values()].filter(o=>o.buyerId===req.user.id||o.sellerId===req.user.id));
});

app.post("/api/orders/:id/complete",requireUser,(req,res)=>{
  const o=store.orders.get(req.params.id);
  if(!o) return res.status(404).json({error:"order_not_found"});
  if(o.buyerId!==req.user.id) return res.status(403).json({error:"buyer_confirmation_required"});
  if(o.status!=="pending") return res.status(409).json({error:"invalid_order_state"});
  o.status="completed"; o.completedAt=now();
  store.ledger.push({id:id("txn"),userId:o.sellerId,orderId:o.id,type:"earning",amount:o.sellerNet,status:"posted",createdAt:now()});
  store.ledger.push({id:id("txn"),userId:"PLATFORM",orderId:o.id,type:"commission",amount:o.commission,status:"posted",createdAt:now()});
  audit(req.user.id,"order.complete",o.id); res.json(o);
});

app.get("/api/wallet",requireUser,(req,res)=>{
  const entries=store.ledger.filter(x=>x.userId===req.user.id);
  const balance=entries.reduce((sum,x)=>sum+(x.type==="earning"?x.amount:-x.amount),0);
  res.json({balance:Number(balance.toFixed(2)),ledger:entries});
});

app.post("/api/withdrawals",requireUser,(req,res)=>{
  const {method,accountRef,amount}=req.body; const n=Number(amount);
  if(!["bkash","nagad","bank"].includes(method)||!accountRef||!(n>0)) return res.status(400).json({error:"invalid_withdrawal"});
  const entries=store.ledger.filter(x=>x.userId===req.user.id);
  const balance=entries.reduce((sum,x)=>sum+(x.type==="earning"?x.amount:-x.amount),0);
  if(n>balance) return res.status(400).json({error:"insufficient_balance"});
  const w={id:id("wd"),userId:req.user.id,method,accountRef,amount:n,status:"pending",createdAt:now()};
  store.withdrawals.set(w.id,w);
  store.ledger.push({id:id("txn"),userId:req.user.id,type:"withdrawal",amount:n,status:"held",withdrawalId:w.id,createdAt:now()});
  audit(req.user.id,"withdrawal.request",w.id); res.status(201).json(w);
});

app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"internal_server_error"})});
app.listen(PORT,()=>console.log(`SkillEarn BD API listening on :${PORT}`));
