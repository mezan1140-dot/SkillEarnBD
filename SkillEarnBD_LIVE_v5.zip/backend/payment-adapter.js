/*
Provider adapter contract.
Do NOT put merchant secrets in the browser.
Implement bKash/Nagad SDK/API calls here after obtaining official merchant credentials.
Required methods:
  createCheckout(order)
  verifyCallback(payload,signature)
  payout(withdrawal)
  queryTransaction(reference)
Every method should be idempotent and log provider_reference.
*/
class PaymentAdapter {
  async createCheckout(order){ throw new Error("NOT_CONFIGURED"); }
  async verifyCallback(payload,signature){ throw new Error("NOT_CONFIGURED"); }
  async payout(withdrawal){ throw new Error("NOT_CONFIGURED"); }
  async queryTransaction(reference){ throw new Error("NOT_CONFIGURED"); }
}
module.exports=PaymentAdapter;
