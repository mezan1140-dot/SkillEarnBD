create extension if not exists pgcrypto;

create table if not exists profiles(
 id uuid primary key,
 full_name text not null,
 email text unique,
 phone text unique,
 role text not null check(role in ('buyer','seller','admin')),
 kyc_status text not null default 'pending' check(kyc_status in ('pending','verified','rejected')),
 created_at timestamptz not null default now()
);

create table if not exists services(
 id uuid primary key default gen_random_uuid(),
 seller_id uuid not null references profiles(id),
 title text not null,
 description text,
 price numeric(12,2) not null check(price>0),
 status text not null default 'active' check(status in ('active','paused','blocked')),
 created_at timestamptz not null default now()
);

create table if not exists orders(
 id uuid primary key default gen_random_uuid(),
 buyer_id uuid not null references profiles(id),
 seller_id uuid not null references profiles(id),
 service_id uuid not null references services(id),
 gross_amount numeric(12,2) not null check(gross_amount>0),
 commission numeric(12,2) not null check(commission>=0),
 seller_net numeric(12,2) not null check(seller_net>=0),
 status text not null default 'pending' check(status in ('pending','accepted','delivered','revision','completed','disputed','cancelled')),
 idempotency_key text unique,
 created_at timestamptz not null default now(),
 completed_at timestamptz
);

create table if not exists wallet_ledger(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references profiles(id),
 order_id uuid references orders(id),
 withdrawal_id uuid,
 type text not null check(type in ('earning','commission','withdrawal','refund','adjustment')),
 amount numeric(12,2) not null check(amount>0),
 status text not null default 'posted' check(status in ('posted','held','reversed')),
 created_at timestamptz not null default now()
);

create table if not exists withdrawals(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references profiles(id),
 method text not null check(method in ('bkash','nagad','bank')),
 account_ref text not null,
 amount numeric(12,2) not null check(amount>0),
 status text not null default 'pending' check(status in ('pending','approved','processing','paid','rejected')),
 provider_reference text,
 created_at timestamptz not null default now(),
 processed_at timestamptz
);

create table if not exists audit_logs(
 id bigserial primary key, actor_id uuid, action text not null, target_type text,
 target_id text, meta jsonb, created_at timestamptz not null default now()
);

create index if not exists idx_orders_buyer on orders(buyer_id);
create index if not exists idx_orders_seller on orders(seller_id);
create index if not exists idx_ledger_user on wallet_ledger(user_id,created_at desc);
create index if not exists idx_withdrawals_status on withdrawals(status);
