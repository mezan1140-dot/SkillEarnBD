# Production launch checklist

- [ ] Deploy API behind HTTPS
- [ ] Use PostgreSQL/Supabase, not in-memory store
- [ ] Implement OTP/password authentication and refresh tokens
- [ ] Hash passwords with Argon2/bcrypt
- [ ] Add RBAC: buyer/seller/admin
- [ ] Add KYC and seller verification
- [ ] Use immutable server-side wallet ledger
- [ ] Use DB transaction + idempotency for order/payment operations
- [ ] Add bKash/Nagad official merchant integration and webhook signature verification
- [ ] Add withdrawal approval + reconciliation
- [ ] Add dispute/refund system
- [ ] Add admin MFA + audit logs
- [ ] Add rate limiting, input validation, CSRF/CORS policy and security headers
- [ ] Add backups, monitoring and error tracking
- [ ] Publish Privacy Policy, Terms, Refund/Dispute Policy
- [ ] Build signed Android AAB and test Play Console release
