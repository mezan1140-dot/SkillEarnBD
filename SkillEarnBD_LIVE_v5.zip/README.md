# SkillEarn BD Live v5 Foundation

This is the upgraded implementation foundation for a real marketplace.

Included:
- Web UI
- Android WebView project
- Server-side order state transitions
- Server-side wallet ledger model
- Withdrawal workflow foundation
- PostgreSQL schema with constraints/indexes
- Payment provider adapter contract
- Admin/security production checklist

Important: payment providers require your own approved merchant/business account and credentials. Never hard-code secrets in the Android app or website.

Run API:
cd backend
npm install
npm start

Then configure a production database and authentication before handling real users or money.
